import { useState } from "react";
import Products from "./components/Products";
import "./App.css";
import ReactDOM from "react-dom/client";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./components/Home";
import ProductDetail from "./components/ProductDetail";
import Nav from "./components/Nav";
import Cart from './components/Cart';
import { CartProvider } from "./contexts/CartProvider";


function App() {
   

  return (
    <>
      
    {/* <Nav/> */}
    <CartProvider>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Nav />}  > 
            <Route index element={<Home />} />
            <Route path="product-detail/:id" element={<ProductDetail />} />
            <Route path="cart" element={<Cart />} />
          </Route>
        </Routes>
      </BrowserRouter>
      </CartProvider>
    </>
  );
}

export default App;
