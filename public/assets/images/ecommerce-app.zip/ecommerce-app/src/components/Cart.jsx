import React, { useState } from 'react'
import { useCart } from '../contexts/CartProvider'
import './Cart.css'
function Cart() {
    
    const {cartItems} = useCart();


  return (
    <div className='cart'>
        {cartItems.map(item => (
            <div key={item.id} className='cartItem'>
                <div className='cartImage'>
                    <img src={item.image} alt={item.title}/>
                </div>
                <div className="cartDetails">
                    <h4>Title: {item.title}</h4>
                    <p>Price: {item.price}</p>
                    <p>Quantity: {item.quantity}</p>
                </div>
                
                
            </div>
        ))}
    </div>
  )
}

export default Cart