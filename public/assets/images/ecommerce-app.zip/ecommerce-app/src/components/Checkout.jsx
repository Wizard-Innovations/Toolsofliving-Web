import React from 'react'

// Define the checkout component
function Checkout({cartItems}) {
  return (
    <div className='checkout'>
        <h3>Checkout</h3>
        {cartItems.map(item =>(
            <div key={item.id} className='checkoutItem'>
                <h4>{item.title}</h4>
                <p>{item.price}</p>
            </div>
        ))}
        {/* Shipping and payment form goes here */}
    </div>
  )
}

export default Checkout