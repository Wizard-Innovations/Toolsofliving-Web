import React from 'react'
import Products from "./Products";
import Nav from './Nav';


function Home() {
  return (
    <> 
    
    <Products/>
    </>
  )
}

export default Home