import React, { useEffect, useState } from 'react'
import './Nav.css'
import { Outlet, Link } from "react-router-dom";
import { useCart } from '../contexts/CartProvider'




function Nav() {

    const { cartItems } = useCart();
    console.log(cartItems)
    const handleCartPopup = (event) => {
        const cartBtn = event.currentTarget;
        if (cartBtn.classList.contains("active")) {
            cartBtn.classList.remove("active")
        }
        else {
            cartBtn.classList.add("active")
        }
    }
    return (
        <>

            <div className='navContainer'>
                <div className='navInner'>


                    <div className='navLogo'>
                        <Link to='/'>Logo</Link>
                    </div>
                    <div className='navMenu'>
                        <ul>
                            <li>
                                <Link to='/'>Home</Link>
                            </li>
                            <li>
                                <button className='cartPopupBtn' onClick={(event) => handleCartPopup(event)}>
                                    <span className='cartCounter'>{cartItems.length}</span>
                                    <i className="fa-solid fa-cart-shopping"></i>
                                    <div className='cartList'>
                                    <div className="cartListInner">
                                    {cartItems.length > 0 ? cartItems.map(item => (
                                            <div key={item.id} className='cartListItem'>
                                                <div className='cartListItemImage'>
                                                    <img src={item.image} alt={item.title} />
                                                </div>
                                                <div className='cartListItemDetails'>
                                                    <h4>{item.title}</h4>
                                                    <p>{item.description}</p>
                                                    <p>Quantity: {item.quantity}</p>
                                                </div>

                                            </div>
                                        )) : (<div className='noItemsFound'>No item in cart</div>)}
                                        <Link to='/cart' className='viewCartBtn'>View Cart</Link>
                                    </div>
                                       

                                    </div>
                                </button>
                            </li>

                        </ul>
                    </div>


                </div>
            </div>
            <Outlet />
        </>
    )
}

export default Nav