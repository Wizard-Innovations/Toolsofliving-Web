import React, { useEffect, useState } from 'react';
import {  useParams  } from "react-router-dom";
import './ProductDetails.css'
import { useCart } from '../contexts/CartProvider'

// Define product component
function ProductDetail() {
    
    const [product, setProduct] = useState([]);

    let { id } = useParams();
    const { addToCart } = useCart();
    // fetch products from api
    useEffect(() => {
        fetch('https://fakestoreapi.com/products/'+id)
            .then(response => response.json())
            .then(data => setProduct(data));
    }, [id]);
    

  return (
    <div className='productContainer'>
            <div key={product.id} className='productInner'>
                <div className='productInnerItem'>
                    <img src={product.image} alt={product.title}/>
                </div>
                <div className='productInnerItem'>
                    <h4>{product.title}</h4>
                    <p>{product.description}</p>
                    
                    <h5>Category</h5>
                    <p>{product.category}</p>

                    
                    {product.rating && (
                        <>
                        <h5>Rating</h5>
                        <p>
                            {product.rating.rate} - {product.rating.count}
                        </p>
                        </>
                    )}
                   
                     
        
                    <button onClick={() => addToCart(product)}>Add to cart</button>
                </div> 
            </div>
    </div>
  )
}

export default ProductDetail