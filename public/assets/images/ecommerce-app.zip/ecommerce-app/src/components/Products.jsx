import React, { useEffect, useState } from 'react';
import './Products.css'
import { Outlet, Link, useParams  } from "react-router-dom";
import { useCart } from '../contexts/CartProvider'

// Define the ProductCard component
function Products() {
  const [products, setProducts] = useState([]);
 
  const { addToCart } = useCart();

    // fetch products from api
    useEffect(() => {
        fetch(`https://fakestoreapi.com/products`)
            .then(response => response.json())
            .then(data => setProducts(data));
    }, []);

    

  return (
    <div className='products'>
        {products.map(product =>(
          <div key={product.id} className='productCard'>   
                <Link to={`/product-detail/${product.id}`} className='productImage'>
                  <img src={product.image} alt={product.title}/>
                </Link>
                <div className='productDesc'>
                <Link to={`/product-detail/${product.id}`}>
                <h4>{product.title}</h4>
                </Link>
                <p>{product.description}</p>
                <button onClick={() => addToCart(product)}>Add to cart</button>
                </div>
          </div>
           
          
        ))}
    </div>
  )
}

export default Products