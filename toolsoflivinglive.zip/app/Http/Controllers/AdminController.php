<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
// use Auth;
use Illuminate\Support\Facades\Auth;

use App\Models\User;
use App\Models\Blog;
use App\Models\BlogCategories;
use App\Models\BlogCategoriesBridge;
use App\Models\Partner;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Str;

class AdminController extends Controller
{
    public function index(Request $request)
    {
        if (Auth::check()) {
            // User is already logged in, redirect to the admin dashboard
            return redirect()->route('dashboard');
        }

        if ($request->isMethod('post')) {
            $credentials = $request->only('email', 'password');

            if (Auth::attempt($credentials)) {
                // Authentication successful, redirect to the admin dashboard
                return redirect()->route('dashboard');
            } else {
                // Authentication failed, display the login form with an error message
                return redirect()->back()->withErrors(['email' => 'Invalid email or password']);
            }
        }

        // User is not logged in, display the login form
        return view('login');
    }
    public function createUserStore(Request $request)
    {
        // dd($request->all());

        $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:8|confirmed',
        ]);

        $user = User::create([
            'name' => $request->name,
            'email' => $request->email,
            'password' => bcrypt($request->password),
        ]);

        return redirect()->route('dashboard');
    }
    public function createUser()
    {

        return view('admin.create-user');
    }

    public function createBlog()
    {
      
        $categories = BlogCategories::orderBy('id', 'desc')->where('status', 1)->where('deleted', 0)->get()->toArray();
        return view('admin.blog')->with(compact('categories'));
    }

    public function createBlogStore(Request $request)
    {
 
        $request->validate([
            'title' => 'required|string|max:255',
            'image' => 'required|image|max:2048', // Max size 2MB
            'short_desc' => 'required|string', // Max size 20MB
            'long_desc' => 'required|string',
            'category' => 'required|array|max:255', 
        ]);

        
        if ($request->hasFile('image')) { 
            $attachment = $request->file('image');
            $profile =  Str::random(3)  . 'blog-image.' . $attachment->getClientOriginalExtension();
            $attachment->move(public_path('uploads/blog-images'), $profile);
            $attachmentPaths[] = $profile;
        }
        // dd($request->category);
        $userId = Auth::id();
        $slug = Str::slug($request->title);
        // dd($slug);
        $blog = Blog::create([
            'title' => $request->title,
            'slug' => $slug,
            'image' => $profile,
            'short_desc' => $request->short_desc,
            'long_desc' => $request->long_desc,
            // 'category' => $request->category  
        ]);

        // Get the ID of the last inserted record
        $lastInsertedId = $blog->id;
        foreach ( $request->category   as $key => $cat_id) {
            BlogCategoriesBridge::create([
                'cat_id' => $cat_id,
                'blog_id' => $lastInsertedId,
                'created_by' => $userId,
            ]);
     
        }
        
        

        return redirect()->back()->with('success', 'Blog added successfully.');
    }
 
 
    public function createBlogCategory()
    {

        return view('admin.blog_categories');
    }

 
    public function createBlogCategoryStore(Request $request)
    {
        $request->validate([
            'category' => 'required|string',
        ]);
        $slug = Str::slug($request->category);
        $userId = Auth::id();
        // Create a new BlogCategory instance
        $category = BlogCategories::create([
            'name' => $request->category,
            'slug' => $slug,
            'created_by' => $userId,

        ]);

        // Optionally, you can return a response or redirect to a specific route
        return redirect()->back()->with('success', 'Blog Category created successfully.');
    }

    public function logout()
    {
        Auth::logout();
        return redirect('/admin');
    }

    public function dashboard()
    {
        return view('admin.index');
    }
    public function createPartner()
    { 
        return view('admin.partner');
    }
    public function createPartnerStore(Request $request)
    {
 
        $request->validate([
            'title' => 'required|string|max:255',
            'image' => 'required|image|max:2048', // Max size 2MB 
            'desc' => 'required|string', 
        ]);

        
        if ($request->hasFile('image')) { 
            $attachment = $request->file('image');
            $profile =  Str::random(3)  . 'partner-image.' . $attachment->getClientOriginalExtension();
            $attachment->move(public_path('uploads/partner-images'), $profile);
            $attachmentPaths[] = $profile;
        }
     
        $slug = Str::slug($request->title);
   
        Partner::create([
            'title' => $request->title,
            'slug' => $slug,
            'image' => $profile, 
            'desc' => $request->desc, 
        ]);

     
        
        return redirect()->back()->with('success', 'Partner added successfully.');
    }
 
}
