<?php

namespace App\Http\Controllers;

use App\Models\Blog;
use App\Models\Partner;
use Illuminate\Http\Request;

class SiteController extends Controller
{
    public function index(){
        $partners = Partner::orderBy("id", "desc")  
        ->where('status', 1)
        ->where('deleted', 0)
        ->get();
        return view('index')->with(compact('partners'));
    }
    public function myHealth(){
        return view('health');
    }
    public function conditions(){
        return view('conditions');
    }
    public function treatments(){
        return view('treatments');
    }
    public function blog(){
        $blogs = Blog::orderBy("id", "desc")
        ->with('categories')  
        ->where('status', 1)
        ->where('deleted', 0)
        ->simplePaginate(3);
       
      //dd($blogs);
        
        return view('blogs')->with(compact('blogs'));
    }
    public function blogDetail($slug){

        $blogs = Blog::with('categories')
        ->where('slug', $slug)
        ->where('status', 1)
        ->where('deleted', 0)
        ->get();

        $limit = 5;
        $related_blogs = Blog::with('categories') 
        ->where('status', 1)
        ->where('slug','!=', $slug)
        ->where('deleted', 0)
        ->take($limit)->get();
        
    // Get the category associated with the current blog
        
        // dd($related_blogs);
        return view('blog-detail')->with(compact('blogs','related_blogs'));
    }
     
    public function becomeMember(){
        return view('become-member');
    }
    public function signIn(){
        return view('index');
    }
    public function partnerDetail($slug) {
        $partner = Partner::orderBy('id','desc') 
        ->where('slug', $slug)
        ->where('status', 1)
        ->where('deleted', 0)
        ->get()->first();
        //  dd($partner);
        $limit = 5;
        $related_partners = Partner::orderBy('id','desc') 
        ->where('status', 1)
        ->where('slug','!=', $slug)
        ->where('deleted', 0)
        ->take($limit)->get();
        return view('partners')->with(compact('partner','related_partners'));
    }
}
