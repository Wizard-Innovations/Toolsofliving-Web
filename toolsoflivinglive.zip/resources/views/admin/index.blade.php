@extends('admin.layouts.master')

@section('title', 'Admin')

@section('content')
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Admin</div>

                <div class="card-body">
                    Welcome to your Admin page.
                </div>
            </div>
        </div>
    </div>
@endsection
