<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\SiteController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

 
Route::match(['GET', 'POST'], '/', [SiteController::class, 'index'])->name('site');
Route::match(['GET', 'POST'], '/my-health', [SiteController::class, 'myHealth'])->name('myHealth');
Route::match(['GET', 'POST'], '/conditions', [SiteController::class, 'conditions'])->name('conditions');
Route::match(['GET', 'POST'], '/treatments', [SiteController::class, 'treatments'])->name('treatments');
Route::match(['GET', 'POST'], '/blog', [SiteController::class, 'blog'])->name('blog');
Route::match(['GET', 'POST'], '/blog/{slug}', [SiteController::class, 'blogDetail'])->name('blogDetail');
Route::match(['GET', 'POST'], '/become-member', [SiteController::class, 'becomeMember'])->name('becomeMember');
Route::match(['GET', 'POST'], '/sign-in', [SiteController::class, 'signIn'])->name('signIn');

Route::match(['GET', 'POST'], '/partner/{slug}', [SiteController::class, 'partnerDetail'])->name('partnerDetail');
 
  
// Admin 
Route::match(['GET', 'POST'], '/admin', [AdminController::class, 'index'])->name('login');

Route::match(['GET', 'POST'], '/logout', [AdminController::class, 'logout'])->name('logout');

// Route::get('/portfolio-videos/{category?}',  [BlogController::class, 'getVideosByCategory'] )->name('getVideosByCategory');
  
Route::prefix('dashboard')->group(function () {
    // Routes inside this group will have the prefix '/admin'
    Route::match(['GET', 'POST'], '/', [AdminController::class, 'dashboard'])->name('dashboard'); 
    
    // user
    Route::get('/create-user', [AdminController::class, 'createUser'])->name('createUser');
    Route::post('/create-user-store', [AdminController::class, 'createUserStore'])->name('createUserStore'); 
    
    // blog
    Route::get('/create-blog', [AdminController::class, 'createBlog'])->name('createBlog');
    Route::post('/create-blog-store', [AdminController::class, 'createBlogStore'])->name('createBlogStore');

    // partner
    Route::get('/create-partner', [AdminController::class, 'createPartner'])->name('createPartner');
    Route::post('/create-partner-store', [AdminController::class, 'createPartnerStore'])->name('createPartnerStore');

    
    
    Route::get('/create-blog-category', [AdminController::class, 'createBlogCategory'])->name('createBlogCategory');
    Route::post('/create-blog-category-store', [AdminController::class, 'createBlogCategoryStore'])->name('createBlogCategoryStore');
    

});

Auth::routes();
