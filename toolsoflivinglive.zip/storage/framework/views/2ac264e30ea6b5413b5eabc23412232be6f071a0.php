<header>
		<div class="bg-lightgreen">
			<div class="container-fluid">
				<div class="main-header">
					<div class="logo-img" data-aos="fade-down" data-aos-duration="2000">
						<a href="<?php echo e(route('site')); ?>">
							<img src="<?php echo e(asset('assets/images/logo.png')); ?>" class="img-fluid" alt="logo-image">
						</a>
					</div>
					<div id="main-nav" class="stellarnav all-Links">
						<ul class="nav-links ms-5">
							 
							
							
							
							 
							
							 
							
							<li>
								<a href="<?php echo e(route('site')); ?>"  class="custom_paragraph">Home</a>
							</li>
							<li>
								<a href="<?php echo e(route('myHealth')); ?>"  class="custom_paragraph">My Health</a>
							</li>
							<li>
								<a href="<?php echo e(route('conditions')); ?>"  class="custom_paragraph">Conditions</a>
							</li>
							<li>
								<a href="<?php echo e(route('treatments')); ?>"  class="custom_paragraph">Treatments</a>
							</li>
							<li>
								<a href="<?php echo e(route('blog')); ?>"  class="custom_paragraph">Blog</a>
							</li>
					 
						
						</ul>
						<ul class="nav-links">
						<li>
								<a href="#"  class="custom_paragraph" data-bs-toggle="modal" data-bs-target="#signInModal">Sign In</a>
							</li> 
							<li class="becomeMemberBtn">
								<a href="<?php echo e(route('becomeMember')); ?>"   class=" custom_paragraph">Become a Member</a>
							</li>  
						</ul>
					</div>
				 
				</div>
			</div>
		</div>
	</header><?php /**PATH /home/cg8amjk11jto/public_html/toolsofliving.com/resources/views/layouts/includes/header.blade.php ENDPATH**/ ?>