<!-- Include Select2 CSS -->
<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0-beta.1/css/select2.min.css" rel="stylesheet" />

<?php /**PATH /home/cg8amjk11jto/public_html/toolsofliving.com/resources/views/admin/layouts/includes/css.blade.php ENDPATH**/ ?>