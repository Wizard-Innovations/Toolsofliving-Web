<!-- Include Select2 JavaScript -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.1.0-beta.1/js/select2.min.js"></script>
<script src="https://cdn.ckeditor.com/4.22.1/standard/ckeditor.js"></script>
<script>
    CKEDITOR.replace('long_desc');
</script>
<script>
    $(document).ready(function() {
        $('#categoryMultiple').select2();
    });
</script>
<?php /**PATH /home/cg8amjk11jto/public_html/toolsofliving.com/resources/views/admin/layouts/includes/script.blade.php ENDPATH**/ ?>