

<?php $__env->startSection('title', 'Admin'); ?>

<?php $__env->startSection('content'); ?>
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Admin</div>

                <div class="card-body">    
                    <form method="POST" action="<?php echo e(route('createUserStore')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="name" class="form-label">Name</label>
                            <input type="text" class="form-control" id="name" value="<?php echo e(old('name')); ?>" name="name" required>
                            <?php if($errors->has('name')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e($errors->first('name')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="mb-3">
                            <label for="email" class="form-label">Email address</label>
                            <input type="email" class="form-control" id="email" value="<?php echo e(old('email')); ?>" name="email" required>
                            <?php if($errors->has('email')): ?>
                            <div class="alert alert-danger">
                                <?php echo e($errors->first('email')); ?>

                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="mb-3">
                            <label for="password" class="form-label">Password</label>
                            <input type="password" class="form-control" id="password" name="password" required>
                            <?php if($errors->has('password')): ?>
                            <div class="alert alert-danger">
                                <?php echo e($errors->first('password')); ?>

                            </div>
                            <?php endif; ?>
                        </div>
                        <div class="mb-3">
                            <label for="confirmPass" class="form-label">Confirm Password</label>
                             
                            <input type="password" class="form-control" id="confirmPass" name="password_confirmation" placeholder="Confirm Password" required>

                            <?php if($errors->has('password')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e($errors->first('password')); ?>

                                </div>
                            <?php endif; ?>
                        </div>
                     
                        <button type="submit" class="">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cg8amjk11jto/public_html/toolsofliving.com/resources/views/admin/create-user.blade.php ENDPATH**/ ?>