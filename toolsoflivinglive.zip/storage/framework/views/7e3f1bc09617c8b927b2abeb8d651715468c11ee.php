

<?php $__env->startSection('title', 'Admin'); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Add Partner</div>
                <div class="card-body">
                    <?php if(session('success')): ?>
                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                            <?php echo e(session('success')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                        </div>
                    <?php endif; ?>
                    <form method="POST" action="<?php echo e(route('createPartnerStore')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        
                        <div class="mb-3">
                            <label for="title" class="form-label">Title</label>
                            <input type="text" class="form-control" id="title" name="title" value="<?php echo e(old('title')); ?>" required>
                            <?php if($errors->has('name')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e($errors->first('name')); ?>

                                </div>
                            <?php endif; ?>
                        </div>

                        <div class="mb-3">
                            <label for="image" class="form-label">Image</label>
                            <input type="file" class="form-control" id="image" name="image">
                            <?php if($errors->has('image')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e($errors->first('image')); ?>

                                </div>
                            <?php endif; ?>
                        </div>

                     

                        <div class="mb-3">
                            <label for="desc" class="form-label">Description</label>
                          
                            <textarea id="desc" name="desc"  class="form-control" cols="30" rows="5"><?php echo e(old('desc')); ?></textarea>
                            <?php if($errors->has('desc')): ?>
                                <div class="alert alert-danger">
                                    <?php echo e($errors->first('desc')); ?>

                                </div>
                            <?php endif; ?>
                        </div>

                       

                

                        <button type="submit" class="">Submit</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/cg8amjk11jto/public_html/toolsofliving.com/resources/views/admin/partner.blade.php ENDPATH**/ ?>