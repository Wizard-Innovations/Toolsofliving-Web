
<script src="<?php echo e(asset('assets/js/bootstrap.min.js')); ?>"></script>
 
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<script src="<?php echo e(asset('assets/js/jquery-3.6.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/stellarnav.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/swiper-bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.fancybox.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/aos.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/custom.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/js/select2.min.js"></script>
<script src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.min.js"></script>

<script>
    AOS.init();
</script>



<?php /**PATH /home/cg8amjk11jto/public_html/toolsofliving.com/resources/views/layouts/includes/script.blade.php ENDPATH**/ ?>